import React from 'react';
import { Festival, LanguageCode } from '../types';
import FestivalCard from './FestivalCard';

// Fix: Implement a Markdown renderer that can handle standard markdown and a special
// case for rendering festival data using the FestivalCard component. It detects
// JSON code blocks in the bot's response and renders them as interactive cards.

interface MarkdownRendererProps {
  content: string;
  selectedLanguage: LanguageCode;
}

const renderSimpleMarkdown = (text: string) => {
  // Basic inline formatting
  const formattedText = text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>');
  return <span dangerouslySetInnerHTML={{ __html: formattedText }} />;
};

const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content, selectedLanguage }) => {
  const festivalJsonRegex = /```json\s*(\[[\s\S]*?\])\s*```/g;
  
  const parts: (string | Festival[])[] = [];
  let lastIndex = 0;
  let match;

  while ((match = festivalJsonRegex.exec(content)) !== null) {
    if (match.index > lastIndex) {
      parts.push(content.substring(lastIndex, match.index));
    }
    try {
      parts.push(JSON.parse(match[1]));
    } catch (e) {
      console.error("Failed to parse festival JSON", e);
      parts.push(match[0]); // fallback to text
    }
    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < content.length) {
    parts.push(content.substring(lastIndex));
  }

  return (
    <div>
      {parts.map((part, index) => {
        if (typeof part === 'string') {
          // Render markdown text blocks
          const blocks = part.trim().split('\n\n');
          return blocks.map((block, i) => {
            if (block.startsWith('# ')) {
              return <h1 key={`${index}-${i}`} className="text-2xl font-bold mb-3">{renderSimpleMarkdown(block.substring(2))}</h1>
            }
            if (block.startsWith('## ')) {
                return <h2 key={`${index}-${i}`} className="text-xl font-bold mb-3">{renderSimpleMarkdown(block.substring(3))}</h2>
            }
            if (block.startsWith('### ')) {
                return <h3 key={`${index}-${i}`} className="text-lg font-bold mb-2">{renderSimpleMarkdown(block.substring(4))}</h3>
            }
            if (block.match(/^\s*([*•-]|\d+\.) /)) {
              const lines = block.split('\n');
              const isOrdered = /^\s*\d+\./.test(lines[0]);
              const ListTag = isOrdered ? 'ol' : 'ul';
              return (
                <ListTag key={`${index}-${i}`} className={`${isOrdered ? 'list-decimal' : 'list-disc'} list-inside pl-4 mb-2`}>
                  {lines.map((line, j) => (
                    <li key={j} className="mb-1">{renderSimpleMarkdown(line.replace(/^\s*([*•-]|\d+\.) /, ''))}</li>
                  ))}
                </ListTag>
              );
            }
            if (block.trim() === '') return null;
            return <p key={`${index}-${i}`} className="mb-2 last:mb-0">{renderSimpleMarkdown(block)}</p>
          });
        }
        if (Array.isArray(part)) {
          // Render festival cards
          return (
            <div key={index}>
              {(part as Festival[]).map((festival, fIndex) => (
                <FestivalCard key={fIndex} festival={festival} selectedLanguage={selectedLanguage} />
              ))}
            </div>
          );
        }
        return null;
      })}
    </div>
  );
};

export default MarkdownRenderer;
