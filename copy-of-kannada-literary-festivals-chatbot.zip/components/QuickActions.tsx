import React from 'react';

interface QuickActionsProps {
  onAction: (action: string) => void;
  disabled?: boolean;
}

const QuickActions: React.FC<QuickActionsProps> = ({ onAction, disabled }) => {
  if(disabled) return null;
  
  return (
    <div className="mb-4 flex flex-wrap gap-2">
      <button
        onClick={() => onAction('List festivals in Bengaluru')}
        className="bg-white text-red-600 border-2 border-red-600 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-red-600 hover:text-white transition-all"
      >
        📍 Events in Bengaluru
      </button>
      <button
        onClick={() => onAction('Which festivals have free entry?')}
        className="bg-white text-yellow-600 border-2 border-yellow-600 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-yellow-600 hover:text-white transition-all"
      >
        🎟️ Free Events
      </button>
      <button
        onClick={() => onAction('Show me a quick calendar of events')}
        className="bg-white text-red-600 border-2 border-red-600 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-red-600 hover:text-white transition-all"
      >
        📅 Calendar
      </button>
      <button
        onClick={() => onAction('Help')}
        className="bg-white text-gray-600 border-2 border-gray-600 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-gray-600 hover:text-white transition-all"
      >
        ❓ Help
      </button>
    </div>
  );
};

export default QuickActions;
