import React from 'react';
import { LanguageCode } from '../types';
import { LANGUAGES } from '../constants';
import { BookIcon } from './Icons';

interface WelcomeProps {
  onLanguageSelect: (lang: LanguageCode) => void;
}

const Welcome: React.FC<WelcomeProps> = ({ onLanguageSelect }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-yellow-50 to-orange-50 flex flex-col items-center justify-center p-4 text-center font-sans">
      <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mb-6 shadow-lg">
        <BookIcon className="w-12 h-12 text-red-600" />
      </div>

      <h1 className="text-4xl md:text-5xl font-extrabold text-gray-800">
        ಕನ್ನಡ ಸಾಹಿತ್ಯ ಉತ್ಸವಗಳಿಗೆ ಸ್ವಾಗತ
      </h1>
      <p className="text-lg md:text-xl text-gray-700 mt-2">
        Welcome to the Kannada Literary Festivals Assistant
      </p>

      <p className="mt-8 text-md text-gray-600">
        ಮುಂದುವರೆಯಲು ದಯವಿಟ್ಟು ನಿಮ್ಮ ಆದ್ಯತೆಯ ಭಾಷೆಯನ್ನು ಆಯ್ಕೆಮಾಡಿ
        <br />
        Please select your preferred language to continue
      </p>

      <div className="mt-8 flex flex-wrap justify-center gap-4 w-full max-w-3xl">
        {Object.entries(LANGUAGES).map(([key, lang]) => (
          <button
            key={key}
            onClick={() => onLanguageSelect(key as LanguageCode)}
            className="min-w-[200px] bg-white border-2 border-red-200 rounded-lg p-4 text-lg font-semibold text-gray-800 hover:bg-red-600 hover:text-white hover:border-red-600 transition-all duration-300 transform hover:scale-105 shadow-md flex items-center justify-center space-x-3"
          >
            <span className="text-2xl">{lang.flag}</span>
            <span>{lang.name}</span>
          </button>
        ))}
      </div>
      
      <footer className="absolute bottom-6 text-gray-500 text-sm">
        <p>ಕಲೆ ಮತ್ತು ಸಂಸ್ಕೃತಿಯ ಆಚರಣೆ | A celebration of art and culture</p>
      </footer>
    </div>
  );
};

export default Welcome;
