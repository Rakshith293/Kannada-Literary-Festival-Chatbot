import React, { useRef, useEffect } from 'react';
import { Message, LanguageCode } from '../types';
import { UserIcon, BookIcon, GlobeIcon } from './Icons';
import MarkdownRenderer from './MarkdownRenderer';

// Fix: Implement the MessageList component to render the chat history.
// This component displays messages from both the user and the bot, handles
// the loading state, and automatically scrolls to the latest message.

interface MessageListProps {
  messages: Message[];
  isLoading: boolean;
  selectedLanguage: LanguageCode;
}

const MessageList: React.FC<MessageListProps> = ({ messages, isLoading, selectedLanguage }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  return (
    <div className="flex-1 overflow-y-auto pr-4 -mr-4 space-y-6">
      {messages.map((message) => (
        <div key={message.id} className={`flex flex-col ${message.type === 'user' ? 'items-end' : 'items-start'}`}>
          <div className={`flex items-start gap-4 w-full ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
            {message.type === 'bot' && (
              <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-yellow-400 rounded-full flex items-center justify-center shrink-0 shadow-md">
                <BookIcon className="w-6 h-6 text-white" />
              </div>
            )}

            <div className={`max-w-xl p-4 rounded-xl shadow-md ${
              message.type === 'user'
                ? 'bg-red-600 text-white rounded-br-none'
                : 'bg-white text-gray-800 rounded-bl-none border border-gray-200'
            }`}>
              {message.imageUrl ? (
                <div className="space-y-2">
                  <p className="text-sm italic">{message.text}</p>
                  <img src={message.imageUrl} alt="Edited content" className="rounded-lg max-w-full h-auto" />
                </div>
              ) : message.type === 'bot' ? (
                <MarkdownRenderer content={message.text} selectedLanguage={selectedLanguage} />
              ) : (
                <p>{message.text}</p>
              )}
              {message.subtext && <p className="text-xs opacity-80 mt-2">{message.subtext}</p>}
            </div>
            
            {message.type === 'user' && (
              <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center shrink-0 shadow-md">
                <UserIcon className="w-6 h-6 text-gray-600" />
              </div>
            )}
          </div>
          {message.type === 'bot' && message.sources && message.sources.length > 0 && (
            <div className="mt-2 pl-14 max-w-xl w-full">
              <h4 className="text-xs font-bold text-gray-600 mb-1">Sources from the web:</h4>
              <div className="space-y-1">
                {message.sources.map((source, index) => (
                  <a key={index} href={source.uri} target="_blank" rel="noopener noreferrer" className="flex items-start text-xs text-blue-600 hover:underline group">
                    <GlobeIcon className="w-3 h-3 mr-1.5 mt-0.5 text-gray-400 group-hover:text-blue-600 shrink-0" />
                    <span className="truncate">{source.title || source.uri}</span>
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      ))}
      {isLoading && (
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-yellow-400 rounded-full flex items-center justify-center shrink-0 shadow-md">
            <BookIcon className="w-6 h-6 text-white" />
          </div>
          <div className="max-w-xl p-4 rounded-xl shadow-md bg-white text-gray-800 rounded-bl-none border border-gray-200">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse [animation-delay:-0.3s]"></div>
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse [animation-delay:-0.15s]"></div>
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            </div>
          </div>
        </div>
      )}
      <div ref={messagesEndRef} />
    </div>
  );
};

export default MessageList;
