
import React from 'react';
import { Festival, LanguageCode } from '../types';
import { CalendarIcon, MapPinIcon, ClockIcon, StarIcon, PhoneIcon, ExternalLinkIcon } from './Icons';

interface FestivalCardProps {
  festival: Festival;
  selectedLanguage: LanguageCode;
}

const FestivalCard: React.FC<FestivalCardProps> = ({ festival, selectedLanguage }) => {
  const getName = () => {
    if (selectedLanguage === 'kannada') return festival.nameKannada;
    if (selectedLanguage === 'hindi') return festival.nameHindi;
    return festival.name;
  };

  return (
    <div className="bg-gradient-to-br from-red-50 to-yellow-50 rounded-lg p-4 mt-3 border-2 border-red-200">
      <div className="mb-3">
        <h4 className="font-bold text-lg text-gray-800">{getName()}</h4>
        <p className="text-xs text-red-600 mt-1">{festival.theme}</p>
        <p className="text-sm text-gray-600 mt-2">{festival.description}</p>
      </div>
      
      <div className="space-y-2 text-sm">
        <div className="flex items-center text-gray-700">
          <CalendarIcon className="w-4 h-4 mr-2 text-red-600" />
          <span>{festival.dates}</span>
        </div>
        <div className="flex items-center text-gray-700">
          <MapPinIcon className="w-4 h-4 mr-2 text-red-600" />
          <span>{festival.venue}, {festival.city}</span>
        </div>
        <div className="flex items-center text-gray-700">
          <ClockIcon className="w-4 h-4 mr-2 text-red-600" />
          <span>{festival.timings}</span>
        </div>
        <div className="flex items-center text-gray-700">
          <StarIcon className="w-4 h-4 mr-2 text-yellow-500" />
          <span className="font-semibold">{festival.entry}</span>
        </div>
      </div>

      {festival.highlights && festival.highlights.length > 0 && (
        <div className="mt-3 pt-3 border-t border-red-200">
          <p className="text-xs font-semibold text-gray-700 mb-2">Highlights:</p>
          <ul className="text-xs text-gray-600 space-y-1">
            {festival.highlights.slice(0, 3).map((h, idx) => (
              <li key={idx} className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                {h}
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-3 pt-3 border-t border-red-200 flex justify-between items-center">
        <div className="text-xs text-gray-600">
          <div className="flex items-center mb-1">
            <PhoneIcon className="w-3 h-3 mr-1" />
            {festival.contact}
          </div>
        </div>
        <a
          href={`https://${festival.website}`}
          target="_blank"
          rel="noopener noreferrer"
          className="bg-gradient-to-r from-red-600 to-yellow-500 text-white px-3 py-1 rounded text-xs flex items-center"
        >
          Website
          <ExternalLinkIcon className="w-3 h-3 ml-1" />
        </a>
      </div>
    </div>
  );
};

export default FestivalCard;