import React from 'react';
import { BookIcon, Volume2Icon, VolumeXIcon, ArrowLeftIcon } from './Icons';
import { LanguageCode } from '../types';
import { LANGUAGES } from '../constants';

interface HeaderProps {
  selectedLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  voiceEnabled: boolean;
  onVoiceToggle: () => void;
  onBack: () => void;
}

const Header: React.FC<HeaderProps> = ({ selectedLanguage, onLanguageChange, voiceEnabled, onVoiceToggle, onBack }) => {
  return (
    <header className="bg-gradient-to-r from-red-600 via-red-500 to-yellow-500 text-white shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <button
              onClick={onBack}
              className="mr-2 p-2 rounded-full hover:bg-white/20 transition-colors"
              aria-label="Go back to language selection"
            >
              <ArrowLeftIcon className="w-6 h-6 text-white" />
            </button>
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mr-3 shrink-0">
              <BookIcon className="w-7 h-7 text-red-600" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold">ಕನ್ನಡ ಸಾಹಿತ್ಯ Assistant</h1>
              <p className="text-xs sm:text-sm opacity-90">Kannada Literary Festivals Chatbot</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <select
              value={selectedLanguage}
              onChange={(e) => onLanguageChange(e.target.value as LanguageCode)}
              className="bg-white text-gray-800 px-3 py-2 rounded-lg text-sm font-semibold"
            >
              {Object.entries(LANGUAGES).map(([key, lang]) => (
                <option key={key} value={key}>
                  {lang.flag} {lang.name}
                </option>
              ))}
            </select>
            <button
              onClick={onVoiceToggle}
              className="bg-white bg-opacity-20 p-2 rounded-lg hover:bg-opacity-30 transition-all"
            >
              {voiceEnabled ? <Volume2Icon className="w-5 h-5" /> : <VolumeXIcon className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;