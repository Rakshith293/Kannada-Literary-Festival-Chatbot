import React from 'react';
import { XIcon } from './Icons';

interface ImagePreviewProps {
  imageSrc: string;
  onClear: () => void;
}

const ImagePreview: React.FC<ImagePreviewProps> = ({ imageSrc, onClear }) => {
  return (
    <div className="mb-4 p-2 bg-gray-100 border border-gray-300 rounded-lg relative w-full max-w-sm mx-auto">
      <p className="text-xs text-center text-gray-600 mb-2 font-semibold">Image to be edited:</p>
      <img src={imageSrc} alt="Preview for editing" className="rounded-md max-h-40 mx-auto" />
      <button
        onClick={onClear}
        className="absolute top-1 right-1 bg-black/50 text-white rounded-full p-1 hover:bg-black/75 transition-colors"
        aria-label="Clear image for editing"
      >
        <XIcon className="w-4 h-4" />
      </button>
    </div>
  );
};

export default ImagePreview;
