import React, { useRef } from 'react';
import { SendIcon, MicIcon, MicOffIcon, PaperclipIcon } from './Icons';

interface ChatInputProps {
  inputValue: string;
  onInputChange: (value: string) => void;
  onSendMessage: () => void;
  isListening: boolean;
  isLoading: boolean;
  onStartListening: () => void;
  onStopListening: () => void;
  onImageUpload: (file: File) => void;
  hasImage: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({
  inputValue,
  onInputChange,
  onSendMessage,
  isListening,
  isLoading,
  onStartListening,
  onStopListening,
  onImageUpload,
  hasImage,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onImageUpload(file);
    }
    // Reset file input to allow uploading the same file again
    if(event.target) {
      event.target.value = '';
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-4">
      <div className="flex items-center space-x-2">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          accept="image/*"
        />
        <button
          onClick={handleUploadClick}
          className="p-3 rounded-lg bg-gray-200 text-gray-700 hover:bg-gray-300 transition-all disabled:opacity-50"
          disabled={isLoading || hasImage}
          aria-label="Upload an image"
        >
          <PaperclipIcon className="w-6 h-6" />
        </button>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => onInputChange(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && onSendMessage()}
          placeholder={hasImage ? "Describe your edits..." : "Ask about festivals..."}
          className="flex-1 border-2 border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:border-red-500"
          disabled={isLoading}
        />
        <button
          onClick={isListening ? onStopListening : onStartListening}
          className={`p-3 rounded-lg transition-all ${
            isListening 
              ? 'bg-red-600 text-white animate-pulse' 
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
          disabled={isLoading || hasImage}
        >
          {isListening ? <MicOffIcon className="w-6 h-6" /> : <MicIcon className="w-6 h-6" />}
        </button>
        <button
          onClick={onSendMessage}
          disabled={!inputValue.trim() || isLoading}
          className="bg-gradient-to-r from-red-600 to-yellow-500 text-white p-3 rounded-lg hover:shadow-lg transition-all disabled:opacity-50"
        >
          <SendIcon className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default ChatInput;
