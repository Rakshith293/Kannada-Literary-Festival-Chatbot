import { Language, LanguageCode } from './types';

export const LANGUAGES: Record<LanguageCode, Language> = {
  english: { name: 'English', code: 'en-IN', flag: '🇬🇧' },
  kannada: { name: 'ಕನ್ನಡ', code: 'kn-IN', flag: '🇮🇳' },
  hindi: { name: 'हिंदी', code: 'hi-IN', flag: '🇮🇳' },
  tamil: { name: 'தமிழ்', code: 'ta-IN', flag: '🇮🇳' },
  telugu: { name: 'తెలుగు', code: 'te-IN', flag: '🇮🇳' }
};
