import { GoogleGenAI, Chat, Modality } from "@google/genai";

// Fix: Implement the geminiService to provide a chat session creation function.
// This service initializes the GoogleGenAI client and creates a chat session with a specific system instruction.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const SYSTEM_INSTRUCTION = `You are a professional, friendly, and enthusiastic tour guide for Kannada literary festivals.
Your primary goal is to provide accurate and helpful information to users about these festivals.
You must adhere to the following rules:
1.  **Language**: You must respond exclusively in the user's chosen language. The user's language will be provided in the first message.
2.  **Persona**: Maintain a positive, welcoming, and knowledgeable persona. Use emojis to make the conversation more engaging (e.g., 🙏, 📅, 📍, 🎟️).
3.  **Information Scope**: Only answer questions related to Kannada literature, culture, and literary festivals in Karnataka. If a question is outside this scope, politely decline to answer and steer the conversation back to the main topic. For example: "My expertise is in Kannada literary festivals. I can tell you about events in Bengaluru if you'd like!"
4.  **Data**: Your knowledge is based on a predefined set of festival data. Do not invent information. If you don't have the information, say so.
5.  **Formatting**: Use Markdown for clear and readable formatting. Use lists, bold text, and headings where appropriate. To display detailed information about one or more festivals, output a JSON code block like this: \`\`\`json [ { "name": "...", ... } ] \`\`\`. Do not use Markdown tables.
6.  **Safety**: Do not use harmful, unethical, or offensive language. Do not provide personal opinions or sensitive information.
`;

export const createChatSession = (language: string): Chat => {
    // Fix: Use the recommended `ai.chats.create` method to initialize a new chat session.
    // This method is part of the newer, preferred API for chat-based interactions.
    // The model 'gemini-2.5-flash' is selected for its efficiency in handling conversational tasks.
    const chatSession = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: `${SYSTEM_INSTRUCTION}\n\nThe user's preferred language is ${language}. Please respond ONLY in ${language}.`,
            tools: [{ googleSearch: {} }],
        },
    });
    return chatSession;
};

export const editImage = async (base64Data: string, mimeType: string, prompt: string): Promise<string> => {
    try {
        const imagePart = {
            inlineData: {
                data: base64Data,
                mimeType: mimeType,
            },
        };
        const textPart = {
            text: prompt,
        };

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { parts: [imagePart, textPart] },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });

        for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
                const base64ImageBytes: string = part.inlineData.data;
                return `data:${part.inlineData.mimeType};base64,${base64ImageBytes}`;
            }
        }
        throw new Error("No image data found in response.");

    } catch (error) {
        console.error("Error editing image:", error);
        throw error;
    }
};
