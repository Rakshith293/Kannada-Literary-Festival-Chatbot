import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Chat } from '@google/genai';
import { Message, LanguageCode, GroundingSource } from './types';
import { LANGUAGES } from './constants';
import { createChatSession, editImage } from './services/geminiService';
import Header from './components/Header';
import MessageList from './components/MessageList';
import QuickActions from './components/QuickActions';
import ChatInput from './components/ChatInput';
import { InfoIcon, Volume2Icon } from './components/Icons';
import Welcome from './components/Welcome';
import ImagePreview from './components/ImagePreview';

// Fix: Add type definitions for the Web Speech API to resolve compilation errors.
// The SpeechRecognition API is not part of the standard TypeScript library and needs to be declared.
interface SpeechRecognitionEvent {
  results: {
    [index: number]: {
      [index: number]: {
        transcript: string;
      };
    };
  };
}

interface SpeechRecognitionErrorEvent {
  error: string;
}

interface SpeechRecognition {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onresult: (event: SpeechRecognitionEvent) => void;
  onerror: (event: SpeechRecognitionErrorEvent) => void;
  onend: () => void;
}

interface SpeechRecognitionStatic {
  new (): SpeechRecognition;
}

declare global {
  interface Window {
    SpeechRecognition: SpeechRecognitionStatic;
    webkitSpeechRecognition: SpeechRecognitionStatic;
  }
}

const initialMessages: Message[] = [
  {
    id: 1,
    type: 'bot',
    text: 'ನಮಸ್ಕಾರ! 🙏 Welcome to Kannada Literary Festivals Assistant!',
    subtext: 'I can provide professional information on Kannada festivals. How can I help?'
  }
];

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [selectedLanguage, setSelectedLanguage] = useState<LanguageCode | null>(null);
  const [uploadedImage, setUploadedImage] = useState<{ data: string; mimeType: string } | null>(null);
  
  const chatSessionRef = useRef<Chat | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const speakRequestCounter = useRef(0);

  const initializeChat = useCallback(() => {
    if (!selectedLanguage) return;
    const languageName = LANGUAGES[selectedLanguage].name;
    chatSessionRef.current = createChatSession(languageName);
  }, [selectedLanguage]);

  useEffect(() => {
    initializeChat();
  }, [initializeChat]);
  
  // Effect for component cleanup
  useEffect(() => {
    return () => {
      window.speechSynthesis?.cancel();
    };
  }, []);

  useEffect(() => {
    if (!selectedLanguage) return;

    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = LANGUAGES[selectedLanguage].code;

      recognitionRef.current.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setInputValue(transcript);
        handleSendMessage(transcript);
        setIsListening(false);
      };

      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognitionRef.current.onend = () => setIsListening(false);
    }
  }, [selectedLanguage]);


  const startListening = () => {
    if (recognitionRef.current && selectedLanguage) {
      try {
        recognitionRef.current.lang = LANGUAGES[selectedLanguage].code;
        recognitionRef.current.start();
        setIsListening(true);
      } catch (e) {
        console.error("Could not start recognition", e);
        setIsListening(false);
      }
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };
  
  const speakText = useCallback(async (text: string) => {
    if (!voiceEnabled || !('speechSynthesis' in window) || !selectedLanguage) {
      return;
    }
    
    const synth = window.speechSynthesis;
    const requestId = ++speakRequestCounter.current;

    const waitForIdleSynth = () => {
      return new Promise<void>((resolve) => {
        const check = () => {
          if (speakRequestCounter.current !== requestId) {
            resolve();
            return;
          }
          if (!synth.speaking) {
            resolve();
          } else {
            setTimeout(check, 50);
          }
        };
        check();
      });
    };
    
    synth.cancel();
    await waitForIdleSynth();

    if (speakRequestCounter.current !== requestId) {
      return;
    }
    
    if (!voiceEnabled || !selectedLanguage) {
      return;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = LANGUAGES[selectedLanguage].code;
    utterance.rate = 0.9;
    
    const onEndOrError = (e?: SpeechSynthesisErrorEvent | SpeechSynthesisEvent) => {
      if (speakRequestCounter.current === requestId) {
        if (e && 'error' in e) {
          console.error(`Speech synthesis error: ${(e as SpeechSynthesisErrorEvent).error}. Language '${utterance.lang}' may not be supported.`);
        }
        setIsSpeaking(false);
      }
    };

    utterance.onstart = () => {
      if (speakRequestCounter.current === requestId) {
        setIsSpeaking(true);
      }
    };
    utterance.onend = onEndOrError;
    utterance.onerror = onEndOrError;
    
    synth.speak(utterance);
  }, [voiceEnabled, selectedLanguage]);
  
  const getSpokenText = (message: Message): string => {
    let spokenText = message.text;
    if (message.subtext) {
        spokenText += ` ${message.subtext}`;
    }
    // Clean up markdown-like formatting for better speech flow
    spokenText = spokenText.replace(/(\*\*|__|\*|_)/g, ''); // Remove bold/italics markers
    spokenText = spokenText.replace(/#{1,6}\s/g, '');  // Remove heading markers
    spokenText = spokenText.replace(/(\n|^)\s*([*•✓-]|\d+\.)\s/g, '\n. '); // Convert list items to pauses
    spokenText = spokenText.replace(/\n{2,}/g, '. '); // Treat paragraph breaks as sentence ends
    spokenText = spokenText.replace(/\n/g, ' '); // Treat single newlines as spaces
    spokenText = spokenText.replace(/\s{2,}/g, ' ').trim(); // Normalize whitespace
    spokenText = spokenText.replace(/(\s\.)+/g, '.'); // Fix weird spacing before periods
    spokenText = spokenText.replace(/\.{2,}/g, '. '); // Normalize multiple periods
    return spokenText;
  };
  
  const handleImageUpload = (file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        setUploadedImage({
            data: base64String,
            mimeType: file.type,
        });
    };
    reader.readAsDataURL(file);
  };

  const handleSendMessage = async (messageText: string) => {
    const trimmedMessage = messageText.trim();
    if (!trimmedMessage || isLoading) return;

    const userMessage: Message = {
      id: Date.now(),
      type: 'user',
      text: trimmedMessage
    };
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      if (uploadedImage) {
        const editedImageUrl = await editImage(uploadedImage.data, uploadedImage.mimeType, trimmedMessage);
        const botMessage: Message = {
          id: Date.now() + 1,
          type: 'bot',
          text: `Here is the edited image for: "${trimmedMessage}"`,
          imageUrl: editedImageUrl,
        };
        setMessages(prev => [...prev, botMessage]);
        setUploadedImage(null);
      } else {
        if (!chatSessionRef.current) {
          initializeChat();
        }
        const result = await chatSessionRef.current!.sendMessage({message: trimmedMessage});
        const responseText = result.text;
        
        const groundingChunks = result.candidates?.[0]?.groundingMetadata?.groundingChunks;
        const sources: GroundingSource[] = (groundingChunks ?? [])
          .map((chunk: any) => ({
            uri: chunk.web?.uri,
            title: chunk.web?.title,
          }))
          .filter((source: any) => source.uri);

        const botMessage: Message = {
          id: Date.now() + 1,
          type: 'bot',
          text: responseText,
          sources: sources,
        };
        
        setMessages(prev => [...prev, botMessage]);
        if (voiceEnabled && botMessage.text) {
          const fullTextToSpeak = getSpokenText(botMessage);
          speakText(fullTextToSpeak);
        }
      }

    } catch (error) {
      console.error("Error sending message or editing image:", error);
      const errorMessage: Message = {
        id: Date.now() + 1,
        type: 'bot',
        text: 'Sorry, something went wrong. Please try again.',
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleQuickAction = (action: string) => {
    handleSendMessage(action);
  };

  const handleLanguageSelect = (lang: LanguageCode) => {
    setSelectedLanguage(lang);
  };

  const handleGoBack = () => {
    setSelectedLanguage(null);
    chatSessionRef.current = null;
    setMessages(initialMessages);
    setInputValue('');
    setIsLoading(false);
    setIsListening(false);
    setUploadedImage(null);
    
    speakRequestCounter.current += 1;
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  };

  if (!selectedLanguage) {
    return <Welcome onLanguageSelect={handleLanguageSelect} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-yellow-50 to-orange-50 flex flex-col font-sans">
      <Header
        selectedLanguage={selectedLanguage}
        onLanguageChange={setSelectedLanguage}
        voiceEnabled={voiceEnabled}
        onVoiceToggle={() => setVoiceEnabled(v => !v)}
        onBack={handleGoBack}
      />

      <main className="flex-1 container mx-auto px-4 py-6 flex flex-col max-w-4xl w-full">
        <MessageList messages={messages} isLoading={isLoading} selectedLanguage={selectedLanguage} />
        
        <div className="mt-auto">
            {uploadedImage && (
              <ImagePreview
                imageSrc={`data:${uploadedImage.mimeType};base64,${uploadedImage.data}`}
                onClear={() => setUploadedImage(null)}
              />
            )}

            {!uploadedImage && <QuickActions onAction={handleQuickAction} />}
            
            <ChatInput 
              inputValue={inputValue}
              onInputChange={setInputValue}
              onSendMessage={() => handleSendMessage(inputValue)}
              isListening={isListening}
              isLoading={isLoading}
              onStartListening={startListening}
              onStopListening={stopListening}
              onImageUpload={handleImageUpload}
              hasImage={!!uploadedImage}
            />

            <p className="text-xs text-gray-500 mt-2 flex items-center justify-between">
              <span className="flex items-center">
                <InfoIcon className="w-3 h-3 mr-1" />
                {uploadedImage ? "Describe your edits in the text box above." : "Ask about festivals or upload an image to edit."}
              </span>
              {isSpeaking && (
                <span className="flex items-center text-red-600 animate-pulse">
                  <Volume2Icon className="w-4 h-4 mr-1" />
                  Speaking...
                </span>
              )}
            </p>
        </div>
      </main>

      <footer className="bg-gray-800 text-white py-4 text-center text-sm">
        <p>Powered by Gemini | ಕನ್ನಡ ಸಾಹಿತ್ಯ ಮತ್ತು ಸಂಸ್ಕೃತಿಯ ಪ್ರಚಾರ</p>
      </footer>
    </div>
  );
};

export default App;
