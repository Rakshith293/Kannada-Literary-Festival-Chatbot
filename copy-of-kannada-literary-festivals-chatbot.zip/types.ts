import { Chat } from "@google/genai";

export interface GroundingSource {
  uri: string;
  title: string;
}

export interface Message {
  id: number;
  type: 'user' | 'bot';
  text: string;
  subtext?: string;
  imageUrl?: string;
  sources?: GroundingSource[];
}

export type LanguageCode = 'english' | 'kannada' | 'hindi' | 'tamil' | 'telugu';

export interface Language {
  name: string;
  code: string;
  flag: string;
}

// Fix: Add the missing 'Festival' type, which is used in FestivalCard.tsx
export interface Festival {
  name: string;
  nameKannada: string;
  nameHindi: string;
  theme: string;
  description: string;
  dates: string;
  venue: string;
  city: string;
  timings: string;
  entry: string;
  highlights: string[];
  contact: string;
  website: string;
}
